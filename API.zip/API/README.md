# API
 The ShellManager API
