class SamlToken < ApplicationRecord
end
