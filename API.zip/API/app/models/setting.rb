class Setting < ApplicationRecord
end
