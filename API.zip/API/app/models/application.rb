class Application < ApplicationRecord
end
