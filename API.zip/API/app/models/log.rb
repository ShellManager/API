class Log < ApplicationRecord
end
