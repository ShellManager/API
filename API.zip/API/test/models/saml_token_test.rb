require 'test_helper'

class SamlTokenTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
