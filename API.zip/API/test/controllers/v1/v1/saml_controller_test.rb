require 'test_helper'

class V1::V1::SamlControllerTest < ActionDispatch::IntegrationTest
  # test "the truth" do
  #   assert true
  # end
end
